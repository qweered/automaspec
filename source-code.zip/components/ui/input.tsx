import type { ComponentProps } from 'react'

import { cn } from '@/lib/utils'

const Input = ({ ref, className, type, ...props }: ComponentProps<'input'>) => {
    return (
        <input
            type={type}
            className={cn(
                'flex h-10 w-full rounded-md border-2 border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground transition-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:border-primary/50 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
                className
            )}
            ref={ref}
            {...props}
        />
    )
}
Input.displayName = 'Input'

export { Input }
