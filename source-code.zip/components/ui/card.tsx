import type { ComponentProps } from 'react'

import { cn } from '@/lib/utils'

const Card = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div
        ref={ref}
        className={cn(
            'rounded-lg border bg-card text-card-foreground shadow-sm shadow-colored transition-smooth border-primary/10',
            className
        )}
        {...props}
    />
)
Card.displayName = 'Card'

const CardHeader = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div ref={ref} className={cn('flex flex-col space-y-1.5 p-6', className)} {...props} />
)
CardHeader.displayName = 'CardHeader'

const CardTitle = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div ref={ref} className={cn('text-2xl font-semibold leading-none tracking-tight', className)} {...props} />
)
CardTitle.displayName = 'CardTitle'

const CardDescription = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div ref={ref} className={cn('text-sm text-muted-foreground', className)} {...props} />
)
CardDescription.displayName = 'CardDescription'

const CardContent = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div ref={ref} className={cn('p-6 pt-0', className)} {...props} />
)
CardContent.displayName = 'CardContent'

const CardFooter = ({ ref, className, ...props }: ComponentProps<'div'>) => (
    <div ref={ref} className={cn('flex items-center p-6 pt-0', className)} {...props} />
)
CardFooter.displayName = 'CardFooter'

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent }
