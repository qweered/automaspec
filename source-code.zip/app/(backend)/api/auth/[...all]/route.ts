import { toNextJsHandler } from 'better-auth/next-js'

import { auth } from '@/lib/shared/better-auth'

export const { GET, POST } = toNextJsHandler(auth.handler)
